function colorYTamanoTexto(inputACambiar){
    inputACambiar.style.color = "red";
    inputACambiar.style.fontSize = "20px";
}

function restablecerColorYTananoTexto(inputACambiar){
    inputACambiar.style.color = "black";
    inputACambiar.style.fontSize = "13px";
}

function cambiarColor(inputACambiar){
    inputACambiar.style.backgroundColor = "beige";
}

function restablecerColor(inputACambiar){
    inputACambiar.style.backgroundColor = "lightcyan";
}